<!-- 

I'm Ryu
https://facebook.com/IdhamDotID

-->

<!DOCTYPE html>
<html lang="en">
<meta http-equiv="content-type" content="text/html;charset=UTF-8" />
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- Primary Meta Tags -->
    <title>SUNDACITYHOST | Add Package</title>
    <meta name="title" content="Frostz Host | Add Package">
    <meta name="description" content="Tools add package khusus client. Gausah ribet minta CEO / Seller untuk Add Package tinggal masukin Username terus submit.">

    <!-- Open Graph / Facebook -->
    <meta property="og:type" content="website">
    <meta property="og:url" content="">
    <meta property="og:title" content="SUNDACITYHOST | Add Package">
    <meta property="og:description" content="Tools add package khusus client. Gausah ribet minta CEO / Seller untuk Add Package tinggal masukin Username terus submit.">
    <meta property="og:image" content="assets/img/logo2.png">

    <!-- Twitter -->
    <meta property="twitter:card" content="summary_large_image">
    <meta property="twitter:url" content="">
    <meta property="twitter:title" content="SUNDACITYHOST | Add Package">
    <meta property="twitter:description" content="Tools add package khusus client. Gausah ribet minta CEO / Seller untuk Add Package tinggal masukin Username terus submit.">
    <meta property="twitter:image" content="">
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <!-- favicon -->
    <link rel="shorcut icon" href="assets/img/logo2.png" sizes="20x20" type="image/png">
    <!-- animate -->
    <link rel="stylesheet" href="assets/css/animate.css">
    <!-- bootstrap -->
    <link rel="stylesheet" href="assets/css/bootstrap.min.css">
    <!-- magnific popup -->
    <link rel="stylesheet" href="assets/css/magnific-popup.css">
    <!-- owl carousel -->
    <link rel="stylesheet" href="assets/css/owl.carousel.min.css">
    <!-- fontawesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <!-- flaticon -->
    <link rel="stylesheet" href="assets/css/flaticon.css">
    <!-- slick slider -->
    <link rel="stylesheet" href="assets/css/slick.css" />
    <!-- slick slider Theme -->
    <link rel="stylesheet" href="assets/css/slick-theme.css" />
    <!-- selectbox -->
    <link href="assets/css/selectbox.min.css" rel="stylesheet">
    <!-- Date Picker -->
    <link href="assets/css/datepicker.min.css" rel="stylesheet" type="text/css">
    <!-- Time Picker -->
    <link rel="stylesheet" href="assets/css/wickedpicker.min.css">
    <!-- Off Canvas Menu Stylesheet -->
    <link rel="stylesheet" href="assets/css/jquery.popuplayer.min.css">
    <!-- Main Stylesheet -->
    <link rel="stylesheet" href="assets/css/style.css">
    <!-- responsive Stylesheet -->
    <link rel="stylesheet" href="assets/css/responsive.css"> 

</head>

<body>
    <!-- preloader area start -->
    <div class="preloader" id="preloader">
        <div class="preloader-inner">
            <div class="spinner">
                <div class="dot1"></div>
                <div class="dot2"></div>
            </div>
        </div>
    </div>
    <!-- preloader area end -->
    <nav class="navbar navbar-area navbar-expand-lg nav-absolute">
        <div class="container nav-container">
            <div class="navbar-brand">
                
                <button class="navbar-toggler collapsed" type="button" data-toggle="collapse"
                    data-target="#malixhost_main_menu" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon-wrap"><i class="fa fa-bars"></i></span>
                </button>
            </div>
            <div class="navbar-collapse collapse white-nav" id="malixhost_main_menu">
                <ul class="navbar-nav">
                    <li><a href="https://www.facebook.com/IdhamDotID">Contact</a></li>
                </ul>
            </div>
        </div>
    </nav>
    <!-- header Part Start-->
    <header>
        <div class="domain-area" style="background-image:url(assets/img/domain_bg.png);">
            <div class="container">
                <div class="row justify-content-center">
                    <div class="col-xl-7">
                        <div class="domain-content-wrapper">
                            <div class="domain-title-wrapper">
                                <h1 class="domain-title">Tools Add Package Client <br> ~ SUNDACITYHOST ~</h1>
                            </div>
                        </div>
                    </div>
                    <div class="col-xl-8 margin-top-50">
                        <div class="search-form-wrapper">
                            <div class="input-group">
                                <input type="text" id="userAcc" class="form-control search-text-field" placeholder="Ketikan username anda disini.">
                            </div>
                            <div class="btn-wrapper margin-top-18">
                                <a id="searchUser" href="javascript:void(0);" class="search-btn">SEARCH</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="showcase-img-wrapper text-center margin-top-30">
                <div class="domain-showcase-img" style="background-image:url(assets/img/4.png);"></div>
            </div>
        </div>  
    </header>

    <!-- Modal -->
    <div class="modalBg">
        <div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Add Package</h5>
                <button type="button" class="close" id="closeModal" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <div class="form-group">
                    <label for="">Username</label>
                    <input type="text" name="userName" id="userName" class="form-control" readonly>
                </div>
                <div class="form-group">
                    <label for="">Package</label>
                    <input type="text" name="package" id="package" class="form-control" readonly>
                </div>
                <section class="domain-price-table desktop-center margin-top-20">
                    <div class="domain-price-table-wrapper table-responsive">
                        <table class="data text-center" style="height: 4px;" id="contentPackage">

                        </table>
                    </div>
                </section>
            </div>
            <div class="modal-footer">
                <button type="button" id="closeModal" class="btn btn-secondary" data-dismiss="modal">Close</button>
                <button type="button" id="addPackage" class="btn btn-primary">Tambahkan Package</button>
            </div>
            </div>
        </div>
        </div>
    </div>
    <!-- header Part END-->
    <!-- Main Sec Part Start Here-->
    
    <!-- jquery -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="assets/js/jquery.min.js"></script>
    <script src="assets/js/jquery-migrate.min.js"></script>
    <!-- Plugin JavaScript -->
    <script src="assets/js/jquery.easing.min.js"></script>
    <!-- popper -->
    <script src="assets/js/popper.min.js"></script>
    <!-- bootstrap -->
    <script src="assets/js/bootstrap.min.js"></script>
    <script  src="assets/js/slick.min.js"></script>
    <!-- Scrolling Nav Plugin -->
    <script src="assets/js/scrolling-nav.js"></script>
    <!-- magnific popup -->
    <script src="assets/js/jquery.magnific-popup.js"></script>
    <!-- wow -->
    <script src="assets/js/wow.min.js"></script>
    <!-- owl carousel -->
    <script src="assets/js/owl.carousel.min.js"></script>
    <!-- waypoint -->
    <script src="assets/js/waypoints.min.js"></script>
    <!-- counterup -->
    <script src="assets/js/jquery.counterup.min.js"></script>
    <!-- imageloaded -->
    <script src="assets/js/imagesloaded.pkgd.min.js"></script>
    <!-- isotope -->
    <script src="assets/js/isotope.pkgd.min.js"></script>
    <!-- DropDown Select Plugin -->
    <script src="assets/js/selectbox.min.js"></script>
    <!-- Date Picker -->
    <script src="assets/js/datepicker.min.js"></script>
    <script src="assets/js/datepicker.en.js"></script>
    <!-- Time Picker -->
    <script src="assets/js/wickedpicker.min.js"></script>
    <!-- Offcanvas Menu -->
    <script src="assets/js/jquery.popuplayer.min.js"></script>
    <!-- main js -->
    <script src="assets/js/main.js"></script>
</body>
</html>