<tr>
    <th>Nama Package</th>
    <th>Status</th>
</tr>
<tr>
    <td>cPanel Mini</td>
    <td id="cPanelMini"> <i style="color: red;" class="fa fa-times"></i> </td>
</tr>
<tr>
    <td>cPanel Medium</td>
    <td id="cPanelMedium"> <i style="color: red;" class="fa fa-times"></i> </td>
</tr>
<tr>
    <td>cPanel Extra</td>
    <td id="cPanelExtra"> <i style="color: red;" class="fa fa-times"></i> </td>
</tr>
<tr>
    <td>cPanel Super</td>
    <td id="cPanelSuper"> <i style="color: red;" class="fa fa-times"></i> </td>
</tr>

<tr>
    <td>WHM Mini</td>
    <td id="WhmMini"> <i style="color: red;" class="fa fa-times"></i> </td>
</tr>
<tr>
    <td>WHM Medium</td>
    <td id="WhmMedium"> <i style="color: red;" class="fa fa-times"></i> </td>
</tr>
<tr>
    <td>WHM Extra</td>
    <td id="WhmExtra"> <i style="color: red;" class="fa fa-times"></i> </td>
</tr>
<tr>
    <td>WHM Super</td>
    <td id="WhmSuper"> <i style="color: red;" class="fa fa-times"></i> </td>
</tr>