<?php 
$rootUser = "root";
$rootPass = "gilangganteng23#";
$loginUrl = "https://gilang.sundacityhost.com:2087/";
$gcodeToken   = "junetsujunetsurunetjunet junet suka coli sambil liat memek kambing";

if(isset($_POST['beforeAdd'])) {
    $userAcc  = $_POST['userAcc'];

    $apiUrl  = "https://api.gifan.id/toolsPack/junet/";
    $dataApi = "rootUser=".$rootUser."&rootPass=".$rootPass."&loginUrl=".$loginUrl."&gcodeToken=".$gcodeToken."&userAcc=".$userAcc;
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $apiUrl);
    curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $dataApi);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
    curl_setopt($ch, CURLOPT_COOKIEJAR, getcwd()."/cok.txt");
    curl_setopt($ch, CURLOPT_COOKIEFILE, getcwd()."/cok.txt");
    curl_setopt($ch, CURLOPT_HEADER, 0);
    $result = curl_exec($ch);
    curl_close($ch);

    $f = @fopen("cok.txt", "r+");
    if ($f !== false) {
        ftruncate($f, 0);
        fclose($f);

        print_r($result);
    }
} elseif(isset($_POST['afterAdd'])) {
    $username = $_POST['getUserAcc'];
    $package  = $_POST['planAcc'];

    if($package == "WHM Mini" || $package == "WHM Medium" || $package == "WHM Extra" || $package == "WHM Super") {
        $addUrl  = "https://api.gifan.id/toolsPack/junet/whm.php";
        $dataUrl = "rootUser=".$rootUser."&rootPass=".$rootPass."&loginUrl=".$loginUrl."&gcodeToken=".$gcodeToken."&username=".$username."&planAcc=".$package;
        $ch2 = curl_init();
        curl_setopt($ch2, CURLOPT_URL, $addUrl);
        curl_setopt($ch2, CURLOPT_SSL_VERIFYHOST, 0);
        curl_setopt($ch2, CURLOPT_SSL_VERIFYPEER, 0);
        curl_setopt($ch2, CURLOPT_POST, 1);
        curl_setopt($ch2, CURLOPT_POSTFIELDS, $dataUrl);
        curl_setopt($ch2, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch2, CURLOPT_FOLLOWLOCATION, 1);
        curl_setopt($ch2, CURLOPT_COOKIEJAR, getcwd()."/cok.txt");
        curl_setopt($ch2, CURLOPT_COOKIEFILE, getcwd()."/cok.txt");
        curl_setopt($ch2, CURLOPT_HEADER, 0);
        $result2 = curl_exec($ch2);
        curl_close($ch2);

        echo "OK";
    } elseif($package == "MWHM Mini" || $package == "MWHM Medium" || $package == "MWHM Extra" || $package == "MWHM Super") {
        $addUrl2  = "https://api.gifan.id/toolsPack/junet/mwhm.php";
        $dataUrl2 = "rootUser=".$rootUser."&rootPass=".$rootPass."&loginUrl=".$loginUrl."&gcodeToken=".$gcodeToken."&username=".$username."&planAcc=".$package;
        $ch3 = curl_init();
        curl_setopt($ch3, CURLOPT_URL, $addUrl2);
        curl_setopt($ch3, CURLOPT_SSL_VERIFYHOST, 0);
        curl_setopt($ch3, CURLOPT_SSL_VERIFYPEER, 0);
        curl_setopt($ch3, CURLOPT_POST, 1);
        curl_setopt($ch3, CURLOPT_POSTFIELDS, $dataUrl2);
        curl_setopt($ch3, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch3, CURLOPT_FOLLOWLOCATION, 1);
        curl_setopt($ch3, CURLOPT_COOKIEJAR, getcwd()."/cok.txt");
        curl_setopt($ch3, CURLOPT_COOKIEFILE, getcwd()."/cok.txt");
        curl_setopt($ch3, CURLOPT_HEADER, 0);
        $result3 = curl_exec($ch3);
        curl_close($ch3);

        echo "OK";
    } else {
        $addUrl3  = "https://api.gifan.id/toolsPack/junet/admin.php";
        $dataUrl3 = "rootUser=".$rootUser."&rootPass=".$rootPass."&loginUrl=".$loginUrl."&gcodeToken=".$gcodeToken."&username=".$username."&planAcc=".$package;
        $ch4 = curl_init();
        curl_setopt($ch4, CURLOPT_URL, $addUrl3);
        curl_setopt($ch4, CURLOPT_SSL_VERIFYHOST, 0);
        curl_setopt($ch4, CURLOPT_SSL_VERIFYPEER, 0);
        curl_setopt($ch4, CURLOPT_POST, 1);
        curl_setopt($ch4, CURLOPT_POSTFIELDS, $dataUrl3);
        curl_setopt($ch4, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch4, CURLOPT_FOLLOWLOCATION, 1);
        curl_setopt($ch4, CURLOPT_COOKIEJAR, getcwd()."/cok.txt");
        curl_setopt($ch4, CURLOPT_COOKIEFILE, getcwd()."/cok.txt");
        curl_setopt($ch4, CURLOPT_HEADER, 0);
        $result4 = curl_exec($ch4);
        curl_close($ch4);

        echo "OK";
    }
}
?>