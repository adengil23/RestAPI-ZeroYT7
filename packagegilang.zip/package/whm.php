<tr>
    <th>Nama Package</th>
    <th>Status</th>
</tr>
<tr>
    <td>cPanel Mini</td>
    <td id="cPanelMini"> <i style="color: red;" class="fa fa-times"></i> </td>
</tr>
<tr>
    <td>cPanel Medium</td>
    <td id="cPanelMedium"> <i style="color: red;" class="fa fa-times"></i> </td>
</tr>
<tr>
    <td>cPanel Extra</td>
    <td id="cPanelExtra"> <i style="color: red;" class="fa fa-times"></i> </td>
</tr>
<tr>
    <td>cPanel Super</td>
    <td id="cPanelSuper"> <i style="color: red;" class="fa fa-times"></i> </td>
</tr>